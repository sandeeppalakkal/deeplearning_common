#include "Convolution.h"
#include <ctime>

double Convolution::run_convolution()
{
  clock_t begin_time;
  clock_t end_time;
  double time_taken = 0;
  int flag_run = 0;
  if (conv_control_params.fixed_float == eFixed)
  {
    if (conv_control_params.dephtwise_planar == eDepthwise)
    {
      if (conv_control_params.data_reuse == eKernelReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_fixed_depthwise_kernel_reuse_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_fixed_depthwise_kernel_reuse_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_fixed_depthwise_kernel_reuse_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_fixed_depthwise_kernel_reuse_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_fixed_depthwise_kernel_reuse(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else
        {
          //cerr << "No mode selected";
          cout << "No mode (loopunroll2/4/8/16) selected";
        }
      }
      else if (conv_control_params.data_reuse == eInputReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_fixed_depthwise_input_reuse_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_fixed_depthwise_input_reuse_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_fixed_depthwise_input_reuse_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_fixed_depthwise_input_reuse_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_fixed_depthwise_input_reuse(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else
        {
          //cerr << "No mode selected";
          cout << "No mode (loopunroll2/4/8/16) selected";
        }
      }
      else if (conv_control_params.data_reuse == eNoReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_fixed_depthwise_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_fixed_depthwise_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_fixed_depthwise_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_fixed_depthwise_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_fixed_depthwise(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else
        {
          //cerr << "No mode selected";
          cout << "No mode (loopunroll2/4/8/16) selected";
        }
      }
      else
      {
        //cerr << "No mode selected";
        cout << "No mode (kernel/input/none) selected";
      }
    }
    else if (conv_control_params.dephtwise_planar == ePlanar)
    {
      //if (conv_control_params.data_reuse == eKernelReuse)
      //{
      //   
      //}
      //else if (conv_control_params.data_reuse == eInputReuse)
      //{

      //}
      //else if (conv_control_params.data_reuse == eNoReuse)
      if (conv_control_params.data_reuse == eNoReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_fixed_planar_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_fixed_planar_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_fixed_planar_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_fixed_planar_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_fixed_planar(conv_params);
          end_time = clock();
          flag_run = 1;
        }
      }
      else
      {
        //cerr << "No mode selected";
        cout << "No mode (kernel/input/none) selected";
      }
    }
    else
    {
      //cerr << "No mode selected";
      cout << "No mode (depthwise/planar) selected";
    }
  }
  else if (conv_control_params.fixed_float == eFloat)
  {
    if (conv_control_params.dephtwise_planar == eDepthwise)
    {

      //Temp 
      //
      //begin_time = clock();
      //convolution_float_planar_unroll16(conv_params);
      //end_time = clock();
      //flag_run = 1;

      if (conv_control_params.data_reuse == eKernelReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_float_depthwise_kernel_reuse_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_float_depthwise_kernel_reuse_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_float_depthwise_kernel_reuse_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_float_depthwise_kernel_reuse_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_float_depthwise_kernel_reuse(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else
        {
          //cerr << "No mode selected";
          cout << "No mode (loopunroll2/4/8/16) selected";
        }
      }
      else if (conv_control_params.data_reuse == eInputReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_float_depthwise_input_reuse_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_float_depthwise_input_reuse_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_float_depthwise_input_reuse_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_float_depthwise_input_reuse_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_float_depthwise_input_reuse(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else
        {
          //cerr << "No mode selected";
          cout << "No mode (loopunroll2/4/8/16) selected";
        }
      }
      else if (conv_control_params.data_reuse == eNoReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_float_depthwise_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_float_depthwise_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_float_depthwise_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_float_depthwise_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_float_depthwise(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else
        {
          //cerr << "No mode selected";
          cout << "No mode (loopunroll2/4/8/16) selected";
        }
      }
      else
      {
        //cerr << "No mode selected";
        cout << "No mode (kernel/input/none) selected";
      }

    }
    else if (conv_control_params.dephtwise_planar == ePlanar)
    {
      if (conv_control_params.data_reuse == eNoReuse)
      {
        if (conv_control_params.loop_unroll == eLoopUnroll2)
        {
          begin_time = clock();
          convolution_float_planar_unroll2(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll4)
        {
          begin_time = clock();
          convolution_float_planar_unroll4(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll8)
        {
          begin_time = clock();
          convolution_float_planar_unroll8(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eLoopUnroll16)
        {
          begin_time = clock();
          convolution_float_planar_unroll16(conv_params);
          end_time = clock();
          flag_run = 1;
        }
        else if (conv_control_params.loop_unroll == eNoLoopUnroll)
        {
          begin_time = clock();
          convolution_float_planar(conv_params);
          end_time = clock();
          flag_run = 1;
        }
      }
      else
      {
        //cerr << "No mode selected";
        cout << "No mode (depthwise/planar) selected";
      }
    }
    else
    {
      //cerr << "No mode selected";
      cout << "No mode (fixed/float) selected";
    }


  }
  if (flag_run == 1)
  {
    time_taken = (double(end_time - begin_time) / double(CLOCKS_PER_SEC)) * double(1000);
  }

  return time_taken;
}

void Convolution::set_conv_control_params(ConvControlParams conv_control_params_val)
{
  //to be set by the app
  conv_control_params.fixed_float = conv_control_params_val.fixed_float;
  conv_control_params.data_access = conv_control_params_val.data_access;
  //conv_control_params.dephtwise_planar = conv_control_params_val.dephtwise_planar;
  //conv_control_params.data_reuse = conv_control_params_val.data_reuse;
  conv_control_params.loop_unroll = conv_control_params_val.loop_unroll;


  if (conv_control_params.data_access == eDepthwiseOnly)
  {
    conv_control_params.dephtwise_planar = eDepthwise;
    conv_control_params.data_reuse = eNoReuse;
  }
  else if (conv_control_params.data_access == ePlanarOnly)
  {
    conv_control_params.dephtwise_planar = ePlanar;
    conv_control_params.data_reuse = eNoReuse;
  }
  else if (conv_control_params.data_access == eDepthwiseInputReuse)
  {
    conv_control_params.dephtwise_planar = eDepthwise;
    conv_control_params.data_reuse = eInputReuse;
  }
  else if (conv_control_params.data_access == eDepthwiseKernelReuse)
  {
    conv_control_params.dephtwise_planar = eDepthwise;
    conv_control_params.data_reuse = eKernelReuse;
  }
  else
  {
    cerr << "Invalid option";
  }
}

void Convolution::set_conv_params(ConvParams conv_params_val)
{
  conv_params.inp_h = conv_params_val.inp_h;
  conv_params.inp_w = conv_params_val.inp_w;
  conv_params.inp_d = conv_params_val.inp_d;
  conv_params.ker_h = conv_params_val.ker_h;
  conv_params.ker_w = conv_params_val.ker_w;
  conv_params.ker_d = conv_params_val.ker_d;
  conv_params.dil_h = conv_params_val.dil_h;
  conv_params.dil_w = conv_params_val.dil_w;
  conv_params.nodes = conv_params_val.nodes;
  conv_params.str_h = conv_params_val.str_h;
  conv_params.str_w = conv_params_val.str_w;
  conv_params.pad_h = conv_params_val.pad_h;
  conv_params.pad_w = conv_params_val.pad_w;
  conv_params.groups = 1;
  conv_params.flag_bias = 1;

  //Set output sizes
  set_output_sizes(&conv_params);
  populate_inputs_params(conv_params);

}

void Convolution::set_output_sizes(ConvParams *conv_params){
  int isize_h = conv_params->inp_h + 2 * conv_params->pad_h;
  int isize_w = conv_params->inp_w + 2 * conv_params->pad_w;

  int kernel_h = (conv_params->ker_h - 1) * conv_params->dil_h + 1;
  int kernel_w = (conv_params->ker_w - 1) * conv_params->dil_w + 1;
  int osize_h = ((isize_h - kernel_h) / conv_params->str_h) + 1;
  int osize_w = ((isize_w - kernel_w) / conv_params->str_w) + 1;
  conv_params->out_h = osize_h;
  conv_params->out_w = osize_w;
}

void Convolution::populate_inputs_params(ConvParams conv_params){
  if (conv_control_params.fixed_float == eFixed)
  {
    int weights_size = conv_params.ker_h * conv_params.ker_w * conv_params.ker_d * conv_params.nodes / conv_params.groups;
    weights = (int16_t *)malloc(weights_size * sizeof(int16_t));
    initialize_int16(weights, weights_size);
    int inputs_size = (conv_params.inp_h + 2 * conv_params.pad_h) * (conv_params.inp_w + 2 * conv_params.pad_w) * conv_params.inp_d;
    inputs = (int16_t *)malloc(inputs_size *sizeof(int16_t));
    initialize_int16(inputs, inputs_size);
    int outputs_size = conv_params.out_h * conv_params.out_w * conv_params.nodes;
    outputs = (int32_t *)malloc(outputs_size *sizeof(int32_t));
    initialize_outputs(outputs, outputs_size);
    if (conv_params.flag_bias){
      biases = (int32_t *)malloc(conv_params.nodes * sizeof(int32_t));
      initialize_int32(biases, conv_params.nodes);
    }
    else {
      biases = NULL;
    }

    biases = (int32_t *)malloc(conv_params.out_h * conv_params.out_w * conv_params.nodes *sizeof(int32_t));
  }
  else if (conv_control_params.fixed_float == eFloat)
  {
    int weights_size = conv_params.ker_h * conv_params.ker_w * conv_params.ker_d * conv_params.nodes / conv_params.groups;
    float_weights = (double *)malloc(weights_size * sizeof(double));
    initialize_float(float_weights, weights_size);
    int inputs_size = (conv_params.inp_h + 2 * conv_params.pad_h) * (conv_params.inp_w + 2 * conv_params.pad_w) * conv_params.inp_d;
    float_inputs = (double *)malloc(inputs_size *sizeof(double));
    initialize_float(float_inputs, inputs_size);
    int outputs_size = conv_params.out_h * conv_params.out_w * conv_params.nodes;
    float_outputs = (double *)malloc(outputs_size *sizeof(double));
    initialize_outputs(float_outputs, outputs_size);
    if (conv_params.flag_bias){
      float_biases = (double *)malloc(conv_params.nodes * sizeof(double));
      initialize_float(float_biases, conv_params.nodes);
    }
    else {
      float_biases = NULL;
    }

    float_biases = (double *)malloc(conv_params.out_h * conv_params.out_w * conv_params.nodes *sizeof(double));
  }


}

void Convolution::initialize_outputs(void *out, int size){
  memset(out, 0, size * sizeof(int32_t));
}
void Convolution::initialize_int16(int16_t *mem, int size){
  for (int i = 0; i < size; i++){
    mem[i] = rand() % INT16_MAX;
  }
}
void Convolution::initialize_int32(int32_t *mem, int size){
  for (int i = 0; i < size; i++){
    mem[i] = rand();
  }
}

void Convolution::initialize_float(double *mem, int size){
  for (int i = 0; i < size; i++){
    mem[i] = rand();
  }
}



