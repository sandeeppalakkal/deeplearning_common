#include <jni.h>
#include <string>
#include "Convolution.h"
#include <ctime>

#define JNI_FUNC_C(RET, FUNC, CLASS)   extern "C" JNIEXPORT RET JNICALL CLASS ## _ ## FUNC
#define JNI_FUNC(RET, FUNC) JNI_FUNC_C(RET, FUNC, Java_com_example_sekharn_convx_MainActivity)

//extern "C" JNIEXPORT jstring JNICALL
//        Java_com_example_sekharn_convx_MainActivity_stringFromJNI
//A obj;
Convolution convObj;

#define INP_H 32
#define INP_W 32
#define INP_D 64
#define KER_H 3
#define KER_W 3
#define NODES 128
#define STR_H 1
#define STR_W 1
#define PAD_H 0
#define PAD_W 0

JNI_FUNC(jstring, stringFromJNI)(
        JNIEnv* env,
        jobject /* this */)
{
    std::string hello = "Welcome to OnDevice AI Demo";
    return env->NewStringUTF(hello.c_str());
}
JNI_FUNC(void, initDefaultConvParams)(
        JNIEnv* env,
        jobject)
{
    ConvParams conv_params;
    conv_params.inp_h = INP_H;
    conv_params.inp_w = INP_W;
    conv_params.inp_d = INP_D;
    conv_params.ker_h = KER_H;
    conv_params.ker_w = KER_W;
    conv_params.ker_d = INP_D;
    conv_params.dil_h = 1;
    conv_params.dil_w = 1;
    conv_params.nodes = NODES;
    conv_params.str_h = STR_H;
    conv_params.str_w = STR_W;
    conv_params.pad_h = PAD_H;
    conv_params.pad_w = PAD_W;
    conv_params.groups = 1;
    conv_params.flag_bias = 1;
    convObj.set_conv_params(conv_params);
}
JNI_FUNC(void, initDefaultConvControlParams)(
        JNIEnv* env,
        jobject) {
    ConvControlParams control_params;
    control_params.fixed_float = eFixed;
    control_params.data_access = eDepthwiseOnly;
    control_params.loop_unroll = eLoopUnroll2;
    convObj.set_conv_control_params(control_params);
}
JNI_FUNC(void, setDimns)(
        JNIEnv* env,
        jobject, jint inp_h, jint inp_w, jint inp_d, jint ker_h, jint ker_w
        ,jint out_nodes)
{
    ConvParams conv_params;
    conv_params.inp_h = inp_h;
    conv_params.inp_w = inp_w;
    conv_params.inp_d = inp_d;
    conv_params.ker_h = ker_h;
    conv_params.ker_w = ker_w;
    conv_params.ker_d = inp_d;
    conv_params.dil_h = 1;
    conv_params.dil_w = 1;
    conv_params.nodes = out_nodes;
    conv_params.str_h = STR_H;
    conv_params.str_w = STR_W;
    conv_params.pad_h = PAD_H;
    conv_params.pad_w = PAD_W;
    conv_params.groups = 1;
    conv_params.flag_bias = 1;
    convObj.set_conv_params(conv_params);
}
JNI_FUNC(void, setConvControlParams)(
        JNIEnv* env,jobject, jint data_type, jint data_access, jint loop_unroll) {
    ConvControlParams control_params;
    control_params.fixed_float = (DataType)data_type;
    control_params.data_access = (DataAccess )data_access;
    control_params.loop_unroll = (LoopUnroll )loop_unroll;
    convObj.set_conv_control_params(control_params);
}
JNI_FUNC(jint, runConvX)(
        JNIEnv* env,
        jobject /* this */)
{
    return convObj.run_convolution();
}