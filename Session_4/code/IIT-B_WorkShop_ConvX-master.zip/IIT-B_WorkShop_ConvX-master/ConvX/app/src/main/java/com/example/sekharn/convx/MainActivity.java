package com.example.sekharn.convx;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    public static final String Results = "Results";
    String Tag = "SRIB";
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("Convex-lib");
    }
    //Spinner sp21,sp22,sp23,sp41,sp42,sp43;
    FloatingActionButton reset,show,run;
    ArrayList<Spinner> spinnerList = new ArrayList<Spinner>();

    public int [][] mOptions = new int[10][7];

    HashMap<Integer, ArrayList<Integer>> execTime = new HashMap<Integer, ArrayList<Integer>>();
    private int mOptSize;


    private int[][] mInputDimns = {{32,32,16},
                                    {32,32,32},
                                    {32,32,64},
                                    {64,64,16},
                                    {64,64,32},
                                    {64,64,64},
                                    {128,128,16},
                                    {128,128,32},
                                    {128,128,64}};

    private int[] mKernelDimns = {1,3,5,7};
    private int[] mNumNodes = {16,32,64};
    private int[] mLOopUnrool = {0,2,4,8,16};
    private TextView onRun;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addSpinners();
        addSpinnerListeners();
        addAdapters();
        addButtonListeners();
        mOptSize = 0;
        onRun = (TextView)findViewById(R.id.textview);

    }
    private void addSpinners(){
        spinnerList.add((Spinner)findViewById(R.id.sp21));
        spinnerList.add((Spinner)findViewById(R.id.sp22));
        spinnerList.add((Spinner)findViewById(R.id.sp23));
        spinnerList.add((Spinner)findViewById(R.id.sp41));
        spinnerList.add((Spinner)findViewById(R.id.sp42));
        spinnerList.add((Spinner)findViewById(R.id.sp43));
    }
    private void addSpinnerListeners(){
        for(int i = 0; i < spinnerList.size();++i){
            spinnerList.get(i).setOnItemSelectedListener(getSpinnerListener());
        }
    }
    private void addAdapters(){
        ArrayList<String> data_type = new ArrayList<String>();
        data_type.add("Fixed");
        data_type.add("Float");
        spinnerList.get(0).setAdapter(getStringAdapter(data_type));

        ArrayList<String> data_access = new ArrayList<String>();
        data_access.add("Planar");
        data_access.add("Depth-OutputReuse");
        data_access.add("Depth-InputReuse");
        data_access.add("Depth-KernelReuse");
        spinnerList.get(1).setAdapter(getStringAdapter(data_access));

        ArrayList<String> unRollingFactor = new ArrayList<String>();
        unRollingFactor.add("None");
        unRollingFactor.add("2");
        unRollingFactor.add("4");
        unRollingFactor.add("8");
        unRollingFactor.add("16");
       // unRollingFactor.add("32");
       // unRollingFactor.add("64");
       // unRollingFactor.add("128");
        spinnerList.get(2).setAdapter(getStringAdapter(unRollingFactor));

        ArrayList<String> input_dimns = new ArrayList<String>();
        input_dimns.add("32x32x16");
        input_dimns.add("32x32x32");
        input_dimns.add("32x32x64");;
        input_dimns.add("64x64x16");
        input_dimns.add("64x64x32");
        input_dimns.add("64x64x64");
        input_dimns.add("128x128x16");
        input_dimns.add("128x128x32");
        input_dimns.add("128x128x64");
        //input_dimns.add("128x128x128");
        spinnerList.get(3).setAdapter(getStringAdapter(input_dimns));

        ArrayList<String> output_channels = new ArrayList<String>();
        output_channels.add("16");
        output_channels.add("32");
        output_channels.add("64");
        //output_channels.add("128");
        spinnerList.get(4).setAdapter(getStringAdapter(output_channels));

        ArrayList<String> kernel_dimns = new ArrayList<String>();
        kernel_dimns.add("1x1");
        kernel_dimns.add("3x3");
        kernel_dimns.add("5x5");
        kernel_dimns.add("7x7");
        spinnerList.get(5).setAdapter(getStringAdapter(kernel_dimns));
        initDefaultConvControlParams();
        initDefaultConvParams();

    }
    private ArrayAdapter<String> getStringAdapter(ArrayList<String> obj){
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, obj);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return dataAdapter;
    }
    private AdapterView.OnItemSelectedListener getSpinnerListener(){
        AdapterView.OnItemSelectedListener spinner_Listener = new  AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

            }
            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
                Log.e(Tag,"onNothingSelected ");
            }
        };
        return spinner_Listener;
    }
    private void addButtonListeners(){
        reset = (FloatingActionButton)findViewById(R.id.reset);
        show = (FloatingActionButton)findViewById(R.id.show);
        run = (FloatingActionButton)findViewById(R.id.run);

       // View.OnClickListener onclick_listener = getOnClickListener();
        reset.setOnClickListener(getOnClickListener());
        show.setOnClickListener(getOnClickListener());
        run.setOnClickListener(getOnClickListener());
    }
    private View.OnClickListener getOnClickListener(){
        View.OnClickListener onclick_listener = new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                switch (v.getId()) {

                    case R.id.reset:
                        resetData();
                        mOptSize = 0;
                        onRun.setText("Choose Conv Options !!");
                        // do your code
                        break;

                    case R.id.show:
                        displayResults();
                        break;

                    case R.id.run:
                        if(7 < mOptSize){
                            onRun.setText("Max Number of Combinations 8");
                        }else {
                            displayOptions();
                            saveOptions();
                            setControlParams();
                            setDimns();
                            run();
                            mOptSize++;
                        }
                        break;

                    default:
                        break;
                }
            }
        };
        return onclick_listener;
    }
    private void resetData(){
        for(int i=0; i<mOptSize;++i){
            ArrayList<Integer> options = new ArrayList<Integer>();
            for(int j = 0; j <7;++j){
                mOptions[i][j] = 0;
            }
        }
        execTime.clear();
    }
    private void displayResults(){
        Intent intent = new Intent(this, DisplayActivity.class);
        for(int i=0; i<mOptSize;++i){
            ArrayList<Integer> options = new ArrayList<Integer>();
            for(int j = 0; j <7;++j){
                options.add(mOptions[i][j]);
            }
            execTime.put(i,options);
        }
        intent.putExtra("map", execTime);
        startActivity(intent);
        //finish();
    }
    private void saveOptions(){
        ArrayList<Integer> options = new ArrayList<Integer>();
        mOptions[mOptSize][1] = getDataTypeIdx(spinnerList.get(0).getSelectedItem().toString());
        mOptions[mOptSize][2] = getDataAccessIdx(spinnerList.get(1).getSelectedItem().toString());
        mOptions[mOptSize][3] = getUnrollingFactorIdx(spinnerList.get(2).getSelectedItem().toString());
        mOptions[mOptSize][4] = getInputDimnsIdx(spinnerList.get(3).getSelectedItem().toString());
        mOptions[mOptSize][5] = getNumNodesIdx(spinnerList.get(4).getSelectedItem().toString());
        mOptions[mOptSize][6] = getKernelDimns(spinnerList.get(5).getSelectedItem().toString());
    }
    private void setDimns(){
        int idx,kdx,ndx;
        idx = getInputDimnsIdx(spinnerList.get(3).getSelectedItem().toString());
        ndx = getNumNodesIdx(spinnerList.get(4).getSelectedItem().toString());
        kdx = getKernelDimns(spinnerList.get(5).getSelectedItem().toString());
        setDimns(mInputDimns[idx][0],mInputDimns[idx][1],mInputDimns[idx][2]
                ,mKernelDimns[kdx],mKernelDimns[kdx],mNumNodes[ndx]);
    }
    private void setControlParams(){
        int dataType,dataAccess,unRolling;
        dataType = getDataTypeIdx(spinnerList.get(0).getSelectedItem().toString());
        dataAccess = getDataAccessIdx(spinnerList.get(1).getSelectedItem().toString());
        unRolling = getUnrollingFactorIdx(spinnerList.get(2).getSelectedItem().toString());

        setConvControlParams(dataType,dataAccess,unRolling);
    }
    private void run(){
        mOptions[mOptSize][0] = runConvX();
        Log.e(Tag,"Execution Time= "+mOptions[mOptSize][0]);
    }
    private void displayOptions(){

        String options = "Convolution Options :\n\n";
        options += "DataType: ";
        options  += spinnerList.get(0).getSelectedItem().toString();
        options += "\nDataAccess: ";
        options  += spinnerList.get(1).getSelectedItem().toString();
        options += "\nLoopUnrolling: ";
        options += spinnerList.get(2).getSelectedItem().toString();
        options += "\nInput Dimensions: ";
        options  += spinnerList.get(3).getSelectedItem().toString();
        options += "\nOutput Channels: ";
        options  += spinnerList.get(4).getSelectedItem().toString();
        options += "\nKernel Dimensions: ";
        options += spinnerList.get(5).getSelectedItem().toString();

        onRun.setText(options);
    }
    private int getDataTypeIdx(String opt){
        if("Fixed" == opt)
            return 0;
        else if("Float" == opt)
            return 1;
        else
            return 2;
    }
    private int getDataAccessIdx(String opt){
        if("Planar" == opt)
            return 0;
        else if("Depth-OutputReuse" == opt)
            return 1;
        else if("Depth-KernelReuse" == opt)
            return 2;
        else if("Depth-InputReuse" == opt)
            return 3;
        else
            return 4;
    }
    private int getUnrollingFactorIdx(String opt){
        if("None" == opt)
            return 0;
        else if("2" == opt)
            return 1;
        else if("4" == opt)
            return 2;
        else if("8" == opt)
            return 3;
        else if("16" == opt)
            return 4;
    /*    else if("32" == opt)
            return 4;
        else if("64" == opt)
            return 5;
        else if("128" == opt)
            return 6; */
        else
            return 4;

    }
    private int getInputDimnsIdx(String opt){
        if("32x32x16" == opt)
            return 0;
        else if("32x32x32" == opt)
            return 1;
        else if("32x32x64" == opt)
            return 2;
        else if("64x64x16" == opt)
            return 3;
        else if("64x64x32" == opt)
            return 4;
        else if("64x64x64" == opt)
            return 5;
        else if("128x128x16" == opt)
            return 6;
        else if("128x128x32" == opt)
            return 7;
        else if("128x128x64" == opt)
            return 8;
        else
            return 9;
    }

    private int getNumNodesIdx(String opt){
        if("16" == opt)
            return 0;
        else if("32" == opt)
            return 1;
        else if("64" == opt)
            return 2;
        else
            return 3;
    }
    private int getKernelDimns(String opt){

        if("1x1" == opt)
            return 0;
        else if("3x3" == opt)
            return 1;
        else if("5x5" == opt)
            return 2;
        else if("7x7" == opt)
            return 3;
        else
            return 4;
    }
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
    public native void initDefaultConvParams();
    public native void initDefaultConvControlParams();
    public native void setDimns(int inp_h, int inp_w, int inp_d,
                                     int ker_h, int ker_w,int out_nodes);
    public native void setConvControlParams(int data_type, int data_access, int loop_unroll);
    public native int runConvX();
   // public native Integer runConvXFromJNI();
}
