package com.example.sekharn.convx;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.DataPointInterface;
import com.jjoe64.graphview.series.OnDataPointTapListener;
import com.jjoe64.graphview.series.Series;

import java.util.ArrayList;
import java.util.HashMap;

public class DisplayActivity extends AppCompatActivity {


    public int [][] mOptions = new int[10][7];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();

        //String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        HashMap<Integer, ArrayList<Integer>> execTime = (HashMap<Integer, ArrayList<Integer>>) intent.getSerializableExtra("map");
        DataPoint[] points = new DataPoint[execTime.size()];
        //Log.e(Tag,"Execution_Size= "+execution_time.size());
        for(int i=0;i<execTime.size();++i){

            ArrayList<Integer> options= execTime.get(i);
            points[i] = new DataPoint(i+1,options.get(0));
            for(int j = 0; j <7;++j){
                mOptions[i+1][j] =  options.get(j);
            }
        }
        GraphView graph = (GraphView) findViewById(R.id.bargraph);
        BarGraphSeries<DataPoint> series = new BarGraphSeries<>(points);

       // graph.getViewport().setScrollable(true);
        //graph.getViewport().setScalable(true);
        graph.getViewport().setXAxisBoundsManual(true);
        //graph.getGridLabelRenderer().setGridColor(Color.DKGRAY);
        graph.getGridLabelRenderer().setNumHorizontalLabels(9);
        graph.getViewport().setMinX(0.0);
        graph.getViewport().setMaxX(8.0);
        graph.getViewport().setScalable(true);
        graph.getGridLabelRenderer().setHorizontalAxisTitle("Combinations");
        //graph.getGridLabelRenderer().
        graph.getGridLabelRenderer().setHorizontalAxisTitleTextSize(60);
        graph.getGridLabelRenderer().setHorizontalAxisTitleColor(Color.BLACK);
        graph.getGridLabelRenderer().setGridStyle(GridLabelRenderer.GridStyle.NONE);
        graph.getViewport().setDrawBorder(true);
        graph.getGridLabelRenderer().setVerticalLabelsVisible(false);
        //graph.getViewport().setBackgroundColor(Color.GRAY);
        //graph.getGridLabelRenderer().setVerticalAxisTitle("Execution Time in ms");
        //graph.getGridLabelRenderer().setVerticalAxisTitleTextSize(50);
        //graph.getGridLabelRenderer().setVerticalAxisTitleColor(Color.GREEN);
        graph.addSeries(series);
        series.setSpacing(75);
        series.setOnDataPointTapListener(new OnDataPointTapListener() {
            @Override
            public void onTap(Series series, DataPointInterface dataPoint) {

                TextView onclick_view = (TextView)findViewById(R.id.tv);
                int x = (int)dataPoint.getX();
                String options = "Options:\n\n";
                options += "DataType: "+getDattype(mOptions[x][1]);
                options += "\nDataAccess: "+getDataAccess(mOptions[x][2]);
                options += "\nLoopUnrolling: "+getUnrollingFactor(mOptions[x][3]);
                options += "\nInput Dimns: "+getInputDimns(mOptions[x][4]);
                options += "\nKernel Dimns: "+getKernelDimns(mOptions[x][6]);
                options += "\n\nExecution Time in ms: "+mOptions[x][0];
                onclick_view.setTextColor(Color.BLACK);

                onclick_view.setText(options);
            }
        });
        series.setDrawValuesOnTop(true);
        series.setValuesOnTopColor(Color.RED);

    }
    private String getDattype(int idx){
        if(0 == idx)
            return "Fixed";
        else if(1 == idx)
            return "Float";
        else
            return "Invalid DataType";
    }
    private String getDataAccess(int idx){
        if(0 == idx)
            return "Depth";
        else if(1 == idx)
            return "Planar";
        else if(2 == idx)
            return "Depth-InputReUse";
        else if(3 == idx)
            return "Depth-KernelReUse";
        else
            return "Invalid DataAccess";
    }
    private String getUnrollingFactor(int idx){
        if(0 == idx)
            return "2";
        else if(1 == idx)
            return "4";
        else if(2 == idx)
            return "8";
        else if(3 == idx)
            return "16";
    /*    else if(4 == idx)
            return "32";
        else if(5 == idx)
            return "64";
        else if(6 == idx)
            return "128"; */
        else
            return "Invalid Option";

    }
    private String getInputDimns(int idx){
        if(0 == idx)
            return "128x128x8";
        else if(1 == idx)
            return "128x128x16";
        else if(2 == idx)
            return "128x128x32";
        else if(3 == idx)
            return "128x128x64";
     //   else if(4 == idx)
      //      return "128x128x128";
        else
            return "Invalid Option";
    }
    private String getNumNodes(int idx){
        if(0 == idx)
            return "8";
        else if(1 == idx)
            return "16";
        else if(2 == idx)
            return "32";
        else if(3 == idx)
            return "64";
        else
            return "Invalid Option";
    }
    private String getKernelDimns(int idx){
        if(0 == idx)
            return "1x1";
        else if(1 == idx)
            return "3x3";
        else if(2 == idx)
            return "5x5";
        else if(3 == idx)
            return "7x7";
        else if(4 == idx)
            return "9x9";
        else if(5 == idx)
            return "11x11";
        else
            return "Invalid Option";
    }
}
