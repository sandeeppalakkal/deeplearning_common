
enum DataType
{
  eFixed,
  eFloat
};

enum DataAccess
{
    ePlanarOnly,
  eDepthwiseOnly,
  eDepthwiseKernelReuse,
  eDepthwiseInputReuse
};

enum DepthwisePlanar
{
  eDepthwise,
  ePlanar
};

enum DataReuse
{
  eNoReuse,
  eKernelReuse,
  eInputReuse
};

enum LoopUnroll
{
  eNoLoopUnroll,
  eLoopUnroll2,
  eLoopUnroll4,
  eLoopUnroll8,
  eLoopUnroll16
};

struct ConvControlParams
{
  DataType fixed_float;
  DataAccess data_access;
  DepthwisePlanar dephtwise_planar;
  DataReuse data_reuse;
  LoopUnroll loop_unroll;
};

typedef struct ConvParams{
  int inp_h;
  int inp_w;
  int inp_d;
  int out_h;
  int out_w;
  int ker_h;
  int ker_w;
  int ker_d;
  int dil_h;
  int dil_w;
  int nodes;
  int str_h;
  int str_w;
  int pad_h;
  int pad_w;
  int groups;
  int flag_bias;
} ConvParams;