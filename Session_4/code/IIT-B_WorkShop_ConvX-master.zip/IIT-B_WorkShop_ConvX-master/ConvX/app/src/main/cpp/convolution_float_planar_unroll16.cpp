#include"Convolution.h"

void Convolution::convolution_float_planar_unroll16(ConvParams conv_params)
{
  double *out_ptr = float_outputs;
  int32_t remain_nodes = conv_params.nodes;
  double *weights_ptr = float_weights;
  double *inp_ptr = float_inputs;
  double *weights_ptr_base = weights_ptr;
  double *kernel_ptr = NULL;
  int32_t row_idx, col_idx;
  int out_depth = conv_params.nodes;
  int inp_depth = conv_params.inp_d;
  int kernel_h = conv_params.ker_h;
  int kernel_w = conv_params.ker_w;
  int dilation_h = conv_params.dil_h;
  int dilation_w = conv_params.dil_w;
  int inp_next_row_offset = conv_params.inp_w;
  int conv_inp_depth = conv_params.inp_d;
  int inp_ch_size = (conv_params.inp_h + 2 * conv_params.pad_h)* (conv_params.inp_w + 2 * conv_params.pad_w);
  int out_ch_size = conv_params.out_h * conv_params.out_w;

  int inp_w = conv_params.inp_w + 2 * conv_params.pad_w;
  for (int node_idx = 0; node_idx < remain_nodes; ++node_idx){
    double *out_ptr_node = float_outputs + node_idx * out_ch_size;
    double *wt_ptr_node = weights_ptr_base + node_idx * kernel_h * kernel_w * inp_depth;
    for (row_idx = 0; row_idx < conv_params.out_h; ++row_idx){
      for (col_idx = 0; col_idx < conv_params.out_w; ++col_idx){
        int32_t inp_col_idx = col_idx * conv_params.str_w;
        int32_t inp_row_idx = row_idx * conv_params.str_h;
        out_ptr = out_ptr_node + row_idx * conv_params.out_w + col_idx;
        int32_t out_val = 0;
        //for (int ch_idx = 0; ch_idx < inp_depth; ++ch_idx){
        //  kernel_ptr = wt_ptr_node + (ch_idx * kernel_h * kernel_w);
        //  inp_ptr = float_inputs + ch_idx * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
        for (int k_row_index = 0; k_row_index < kernel_h; ++k_row_index){
          for (int k_col_index = 0; k_col_index < kernel_w; ++k_col_index){
            int inp_depth_loop_unroll = 16 * (inp_depth / 16);
            for (int ch_idx = 0; ch_idx < inp_depth_loop_unroll; ch_idx += 16){
              kernel_ptr = wt_ptr_node + (ch_idx * kernel_h * kernel_w);
              inp_ptr = float_inputs + ch_idx * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 1) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 1) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 2) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 2) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 3) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 3) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 4) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 4) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 5) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 5) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 6) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 6) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 7) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 7) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 8) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 8) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 9) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 9) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 10) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 10) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 11) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 11) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 12) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 12) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 13) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 13) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 14) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 14) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];

              kernel_ptr = wt_ptr_node + ((ch_idx + 15) * kernel_h * kernel_w);
              inp_ptr = float_inputs + (ch_idx + 15) * inp_ch_size + inp_row_idx * inp_w + inp_col_idx;
              out_val += inp_ptr[k_col_index] * kernel_ptr[k_col_index];
            }
          }
          inp_ptr += inp_w;
          kernel_ptr += kernel_w;
        }
        //}
        int32_t bias_node0;
        if (float_biases != NULL)
        {
          bias_node0 = (float_biases[node_idx]);
          out_val = (int32_t)(((bias_node0)
            +(((int64_t)out_val))));
        }

        // ReLU 
        if (flag_relu)
        {
          out_val = out_val > 0 ? out_val : 0;
        }
        *out_ptr = out_val;
      }
    }
  }
}